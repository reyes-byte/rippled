# Ballast results handoff

Verify without Nix or a compiler:

```sh
python3 verify.py verify .
```

This checks file integrity, fixture fingerprints/transaction IDs, the full CSV matrix, sidecars, and the recorded summary. It does not rerun signature cryptography or prove authenticity of the publisher. Full native tests are available through bin/ballast-handoff in the source repository.

Results are warm scoped C++ allocation requests, not RSS or all heap memory. Input storage is excluded; verify-only also excludes the parsed transaction. Timing includes instrumentation overhead. No ledger authorization, fee validation, network submission, or node-wide lower bound is claimed.

CSVs are gzip-compressed losslessly; JSON sidecars and summary remain readable. The source manifest identifies measured code, not every source file in this data bundle. Public fixture keys must never be used for funds.

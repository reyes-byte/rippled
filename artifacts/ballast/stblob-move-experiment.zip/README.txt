Ballast STBlob move-constructor experiment

Two real protocol-subset builds: pristine pinned candidate header (baseline)
and the local STBlob header overlay (move). candidate_commit is the base Git
revision, not the identity of the modified overlay. Each variant has its own
compiled dependency-manifest hash and stblob_move build flag. The source
headers, harness files, manifest, and test logs are included. See EXPERIMENT.md.

Both variants passed 164 tests. Three fresh runs each: 1620 samples per variant.
For 32 ML-DSA-44 signers, parse requests fell 877665 -> 680801 bytes, with
598 -> 502 allocation calls. Peak remained 312232 bytes; operation-end live
bytes remained 131120. This reduces allocation traffic, not the observed peak.

Coverage: intercepted C++ allocation requests. Wire input excluded; verify-only
also excludes the parsed transaction. Stack, C allocation paths, OpenSSL
internals, tracker metadata, and allocator bookkeeping excluded. No RSS,
node-wide memory, ledger-authorization, or production-readiness claim.

Offline checking (Python without -O; SHA-256 checks are not signatures):
  1. Extract the ZIP into an empty directory and enter that directory.
  2. Run: sha256sum -c checksums.sha256
  3. Decompress baseline/results/run-*.csv.gz and move/results/run-*.csv.gz.
  4. Run separately for each variant:
     python3 ballast/measurement/validate_csv.py baseline/results/run-*.csv
     python3 ballast/measurement/validate_csv.py move/results/run-*.csv
These commands validate raw CSV semantics and derive the recorded summary
statistics. They do not rerun native cryptography. Do not mix variants in
one validator invocation: their configurations intentionally differ.

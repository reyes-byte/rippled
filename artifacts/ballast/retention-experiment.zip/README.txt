Ballast retained-object experiment

This is actual SerialIter -> STTx parsing and checkSign(), keeping 1, 10, 100,
or 1000 objects alive together. Each entry owns an independent wire copy.
The original six-fixture corpus is outside the measured scope. All entries,
wire copies, and the vector storage are destroyed before scope end.

Each batch repeats one fixture and transaction ID. This is not a real node
queue, 1000 unique transactions, parallel execution, or network submission.
Ledger authorization and fees are not checked. Coverage is intercepted C++
requested bytes, not RSS or a node-wide lower bound. C allocation paths,
OpenSSL internals, stack, allocator bookkeeping and tracker metadata excluded.

Both variants passed 179 tests. Three fresh runs each produced 72 rows per
variant (144 total), one sample per fixture/count after one discarded warm-up.
Each algorithm uses the 1/8/32 signer matrix; retained-object counts form a
separate axis. Allocation metrics were stable, every recorded transaction
passed signature/identity checks, and final tracked live bytes/blocks were zero.
valid_signatures counts transactions whose full checkSign() passed, not
individual signatures within each multisigned transaction.

For 1000 ML-DSA-44 transactions with 32 signers: wires 120464000 B, container
152000 B, parsed increment 131120000 B, held 251736000 B (~240.1 MiB), peak
251917112 B. Held/peak bytes were identical in both variants. Cumulative
requests: baseline 1123001000 B, move constructor 926137000 B. These results
have a broader scope than the earlier parse-only allocation-traffic experiment.

candidate_commit identifies the pristine base commit. The move build uses
an opt-in STBlob header overlay; its source fingerprint and stblob_move=ON
flag identify that modification. Each variant has its own compiled retention
manifest hash, verified against its CSV rows. See ballast/retention/README.md
for the complete implementation flow and reproduction commands.

Offline checks, after extraction into an empty directory:
  sha256sum -c checksums.sha256
  gzip -dk baseline/results/run-*.csv.gz
  gzip -dk move/results/run-*.csv.gz
  python3 ballast/retention/validate_csv.py baseline/results/run-*.csv
  python3 ballast/retention/validate_csv.py move/results/run-*.csv
Use Python without -O. Summaries can be recomputed separately for each variant.
The validator checks row/sidecar semantics and the fixed fixture corpus.
checksums.sha256 protects the archived payload; hashes are not publisher
signatures. Offline checking does not rerun native cryptography. Per-variant
manifest fingerprints are recorded in validation.json and CSV/JSON metadata.

The existing dashboard comparison uses the separate single-operation schema.
This archive is not directly imported into that comparison view.
